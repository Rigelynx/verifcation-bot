// Paquete de actualizacion manual: inicia los archivos locales sin descargar GitHub.
require('./src/index.js');
