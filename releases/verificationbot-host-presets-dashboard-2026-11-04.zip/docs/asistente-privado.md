# Asistente privado con DeepSeek

El asistente dispone del mismo historial privado y herramientas desde Discord y la web. La integración está implementada; para usar el modelo real hay que configurar su clave de API directa. Las pruebas automatizadas utilizan un proveedor simulado y servidores ficticios: no crean canales o roles reales.

## Activación

1. Usa `.env.assistant.example` como referencia para las variables de HolyHosting. Configura `GUILD_ID` con el servidor que administrará el bot.
2. Configura `DEEPSEEK_API_KEY` y usa el modelo automático `deepseek-flash` (`ASSISTANT_MODEL` vacío), o indica otro modelo válido de la API directa.
3. Configura hasta 10 IDs de Discord en `ASSISTANT_ALLOWED_IDS`, separados por comas. Vacío permite únicamente al propietario del servidor. Un rol de Alto Mando o una clave administrativa web no bastan para entrar al asistente.
4. Activa `ASSISTANT_ENABLED=true` y reinicia el bot con `npm start`. La clave permanece en el servidor y nunca se devuelve al navegador.
5. Para usar la web, configura además el [inicio con Discord](discord-web.md). El callback OAuth existente sirve para `/asistente`.


Referencia oficial: [API DeepSeek](https://api-docs.deepseek.com/).

## Accesos y ejemplos

- Discord: `/asistente preguntar peticion:Resume los eventos recientes`, `/asistente web` y `/asistente nuevo` para empezar sin contexto anterior.
- Web: `WEB_URL/asistente`, botón Asistente del panel principal e inicio con la propia cuenta de Discord.
- Ejemplos: «Resume los últimos mensajes de #operaciones», «Investiga qué canales de texto se usan más y dime qué muestra revisaste», «Crea un rol llamado Patrulla Alpha con color #b8cba6», «Crea un canal de voz llamado Briefing dentro de la categoría Operaciones».

El usuario y el bot deben tener los permisos nativos de Discord que exige cada acción. La lista privada concede acceso al asistente, no permisos administrativos adicionales. La matriz existente puede deshabilitar `asistente:preguntar` tanto para Discord como para la web.

## Herramientas disponibles

| Herramienta | Alcance |
| --- | --- |
| `server_inventory` | Canales visibles para el usuario y el bot, nombres e IDs de roles |
| `read_channel` | Hasta 50 mensajes recientes de un canal de texto o anuncios accesible; texto acotado, fechas y enlaces |
| `channel_usage` | Hasta 8 canales y 30 mensajes recientes por canal; muestra explícita, sin afirmar inactividad histórica ni medir voz |
| `event_summary` | Un evento por ID o los últimos 10 visibles según sus canales: estado, asistencia y datos guardados del AAR |
| `send_message` | Envía texto con formato de Discord y hasta 10 embeds a un canal de texto o anuncios accesible; devuelve ID y enlace del mensaje y deja auditoría |
| `propose_creations` | Guarda una propuesta concreta cuando se piden ideas o planificación; no modifica Discord |
| `create_channel` | Texto, voz o categoría; con categoría hereda permisos, sin categoría queda privado para solicitante y bot |
| `create_role` | Rol nuevo sin permisos, sin asignación a miembros ni mención masiva |
| `propose_actions` | Plan concreto de creaciones, cambios, borrados, asignaciones y permisos; no ejecuta las acciones |
| `inspect_channel` / `inspect_role` | Configuración, posición y permisos; el rol puede consultar miembros completos con `fetch_members=true` |
| `find_members` / `member_info` | Buscar miembros y consultar sus roles dentro de la comunidad actual |
| `permission_catalog` | Nombres de los permisos reconocidos y ejemplos en español |
| `update_channel` | Nombre, tema, modo lento, NSFW y opciones de voz compatibles |
| `move_channel` / `reorder_channel` | Cambiar categoría o posición; mover conserva las excepciones de permisos |
| `delete_channel` | Borrar un canal o categoría solicitados; una categoría no borra sus hijos |
| `update_role` / `reorder_role` | Nombre, color, visibilidad, mención y posición dentro de la jerarquía permitida |
| `delete_role` | Borrar roles que el usuario y el bot pueden gestionar |
| `assign_role` / `remove_role` | Añadir o retirar un rol de un miembro, conservando los demás |
| `set_role_permissions` | Conceder/retirar flags globales del rol, incluidos los de `@everyone`, conservando los no indicados |
| `set_channel_permissions` | Excepciones para un rol o miembro: permitir, denegar o heredar por permiso |
| `sync_channel_permissions` | Sustituir las excepciones del canal por las de su categoría |

El asistente tiene instrucciones de tomar iniciativa y resolver el encargo completo: puede elegir nombres, colores, tipos y distribución cuando el usuario le delega esos detalles, consultar el inventario y ejecutar sin exigir una confirmación adicional para cada paso. También puede conversar y ayudar con temas generales. Las creaciones admiten órdenes coloquiales y autorizaciones que continúan vigentes en el historial; ya no se exige una combinación literal de «crear» y «canal/rol».

Una consulta aislada al modelo interpreta el alcance autorizado usando la conversación de esa cuenta y servidor y el plan pendiente. No recibe los resultados de herramientas de esa petición. Las creaciones comparten la interpretación general de su encargo; las demás modificaciones verifican cada combinación de herramienta, destino y argumentos concretos, para no extender una orden sobre un canal a otro distinto. Se registra el consumo de todas esas consultas. Sigue dependiendo de la interpretación del modelo; las pruebas usan decisiones simuladas y no garantizan cómo responderá en cada conversación real. Los permisos de Discord y las herramientas habilitadas se comprueban en el servidor antes de ejecutar.

La interpretación usa la [salida JSON de DeepSeek](https://api-docs.deepseek.com/guides/json_mode/), con esquema validado localmente. Una respuesta vacía o inválida no concede autorización para escribir.

`propose_actions` permite planificar todas las acciones de gestión; `propose_creations` se conserva para planes de creación. No son un requisito previo para ejecutar una tarea delegada. La aprobación de un plan estructurado conserva IDs, nombres, destinos y valores de permisos exactos, incluidas sus listas y campos anidados. El usuario puede cambiar el encargo o aprobar una propuesta antigua expresada solo en texto: el modelo interpreta ese nuevo alcance con la conversación. El historial sigue aislado por usuario y servidor.

Los cambios se registran con autor, ID de petición y motivo en Discord. Las herramientas de gestión guardan además el estado anterior y posterior en auditoría local. El recibo distingue creaciones, cambios, asignaciones y borrados; si el proveedor falla después de modificar algo, informa las acciones completadas. Un fallo de auditoría tras una acción exitosa se comunica sin ocultar que el cambio ya ocurrió.

La API comprueba permisos y jerarquía: no se borran `@everyone` ni roles de integraciones; los roles deben quedar por debajo del bot y del usuario, salvo la excepción del dueño del servidor para su propia jerarquía. No se conceden permisos que no tenga el usuario o el bot. La categoría de destino y los canales deben pertenecer a la comunidad actual y ser accesibles. Los borrados son irreversibles y requieren que el encargo incluya eliminar o limpiar; crear u organizar por sí solo no autoriza borrar. Los canales obligatorios de una comunidad no pueden eliminarse. Estas reglas siguen la [jerarquía y permisos de Discord](https://docs.discord.com/developers/topics/permissions) y las [operaciones de canales](https://docs.discord.com/developers/resources/channel).

Desde `/owner → Configurar IA` se controlan por separado las capacidades de crear, editar y borrar canales y roles; asignar o retirar roles; gestionar permisos; enviar mensajes y embeds; y **Usar comandos del bot**. El envío de mensajes y el uso de comandos empiezan desactivados y debe habilitarlos el propietario para cada comunidad. Las capacidades anteriores conservan su migración desde los permisos de creación correspondientes. Se guardan por comunidad; una nueva instalación sigue necesitando que el propietario habilite su IA. El asistente no puede cambiar sus propias capacidades de `/owner`.

## Publicar mensajes con formato

Después de desplegar la actualización y habilitar **Enviar mensajes y embeds a canales** en Owner, pide, por ejemplo: «Redacta y envía un anuncio de patrulla a #operaciones, con título, lista del equipo y la ubicación como spoiler». Funciona desde `/asistente preguntar` y desde la web. Pedir solo un borrador no autoriza publicarlo. Si delegas redactar y enviar, el asistente compone el mensaje y lo publica usando sus herramientas, sin otro paso de confirmación.

El texto conserva spoilers `||texto||`, negritas, cursivas, subrayado, tachado, encabezados, subtexto, listas, citas, enlaces y código. Discord no interpreta spoilers dentro de bloques de código. También admite embeds con título, descripción, color, campos, autor, pie, imagen y miniatura mediante URL o una imagen adjunta del usuario. Se respetan 2000 caracteres por mensaje, hasta 10 embeds y 6000 caracteres sumados en sus textos; el asistente puede dividir una publicación larga en varios mensajes completos. Las menciones no generan avisos.

En el chat web puedes seleccionar hasta cuatro adjuntos; desde Discord usa **imagen**, **archivo_2**, **archivo_3** y **archivo_4** de `/asistente preguntar`. Se admiten PNG, JPG, WebP, TXT, MD, CSV, JSON y LOG de hasta 2 MB cada uno. Ejemplo: «Envía esta imagen a #anuncios con un título en negrita y oculta la imagen como spoiler». Debes habilitar **Enviar mensajes y embeds a canales** en Owner y tanto tú como el bot debéis poder **Adjuntar archivos** en el canal. Puedes volver a referirte a esa imagen dentro de la misma conversación.

Las imágenes se guardan en la base SQLite del bot, aisladas por cuenta, comunidad y conversación. La vista previa exige sesión de Discord y acceso al asistente; los archivos no tienen una ruta pública. La publicación en Discord es una acción explícita del usuario. Hasta 20 imágenes por cuenta y comunidad se conservan durante 30 días; copias idénticas en el mismo chat comparten archivo. Con deepseek-flash, el modelo recibe el contenido visual de las imágenes adjuntas a la petición. Para consultar adjuntos anteriores puede usar read_attachment. Los archivos de texto se leen hasta 50 000 caracteres; el recorte se comunica al modelo. Los archivos se envían al proveedor únicamente durante una consulta que los utilice. La herramienta `read_channel` consulta mensajes y enlaces/metadatos de adjuntos accesibles, y `server_inventory` muestra canales y roles visibles.

El usuario y el bot necesitan **Ver canal** y **Enviar mensajes** en el destino; para embeds, también **Insertar enlaces**. Se comprueban de nuevo después de interpretar la orden. La auditoría registra actor, canal, contenido e ID del envío. Un fallo del modelo posterior al envío conserva el recibo; repetir la misma petición no reenvía el mensaje. Una orden nueva con otro identificador sí se considera otro envío. Las pruebas usan Discord y DeepSeek simulados; el despliegue real se comprueba en el servidor.

Referencia del formato: [Markdown de Discord](https://support.discord.com/hc/es/articles/210298617-Marcado-de-texto-101-Formato-de-chat-negrita-cursiva-subrayado).

El motor no ejecuta terminal, SQL ni navegación externa. Las publicaciones se realizan mediante las herramientas habilitadas; los comandos del bot se limitan al catálogo descrito más abajo. Los mensajes leídos son datos y no pueden autorizar acciones de gestión.

## Comandos propios del bot desde la IA

En Owner → Configurar IA, activa **Usar comandos del bot** para cada comunidad que lo necesite. Esta nueva capacidad comienza desactivada. Se mantiene la lista privada de acceso al asistente y la matriz de permisos de cada comando; habilitar esta capacidad no concede permisos de oficial o administrador.

`bot_command_catalog` obtiene las opciones y límites de los comandos reales registrados en el código. `run_bot_command` valida esas opciones y llama al mismo manejador que Discord, usando una interfaz que recoge sus respuestas privadas. No envía comandos slash sintéticos a Discord. La compuerta de permisos se comparte con la ejecución normal del bot.

Esta primera entrega conecta economía (consultas, operaciones personales y ajustes administrativos), bonos, servidores privados, convocatoria/entrenamiento/inicio y consultas de eventos, moderación, verificación manual/revocación, expedientes, consultas de tienda y el enlace al portal de patrullas. Las ediciones de canales, roles y permisos siguen disponibles mediante las herramientas existentes. El catálogo muestra las claves habilitadas por la matriz para la cuenta; las comprobaciones internas de cada manejador también pueden rechazar una operación.

Ejemplos: «Consulta mi balance», «Dale 100 créditos a @miembro en la cartera», «Ocupa el servidor privado 2 para Patrulla Alpha», «Convoca una operación llamada Reconocimiento con paga base 100 y plantilla 4 en #operaciones», «Verifica manualmente a @miembro». La IA pregunta por los datos obligatorios que falten. Los comandos personales actúan sobre la cuenta solicitante. Una petición de consulta o borrador no autoriza una modificación, sanción o publicación; la interpretación aislada verifica el comando y sus opciones concretas. También puedes pedir un plan y aprobarlo después.

La moderación exige además los permisos nativos del solicitante y del bot, respeta la jerarquía del solicitante y limita los timeouts a 28 días. Las recompensas de entrenamiento y los roles de verificación se comprueban frente a permisos y jerarquías. Los canales deben pertenecer a la comunidad y ser accesibles para ambos; las publicaciones comprueban permisos de envío e inserción de enlaces.

Quedan pendientes los flujos que necesitan botones/formularios: finalizar eventos, editar sus reportes y confirmar compras. El asistente indica el comando de Discord para completarlos. Tampoco se expone la emisión de sesiones web ni la configuración de accesos mediante `/admin configurar`. Un panel consultado desde la IA devuelve sus textos, pero sus botones no se pueden pulsar desde el chat.

Cada invocación registra su inicio y las respuestas reales con actor e identificador de petición. El historial y el recibo web conservan esas respuestas aunque falle después el proveedor de IA. Que un manejador termine no prueba que haya tenido éxito: puede responder con un rechazo o un panel pendiente. Si lanza una excepción, el resultado se marca incierto y no se reintenta automáticamente. Las llamadas equivalentes se ejecutan una sola vez dentro de la petición; repetir la petición con su mismo ID reutiliza el resultado guardado. Una petición nueva sí puede ejecutar de nuevo una acción.

Ejemplos de peticiones:

- «Mueve los canales de desarrollo a su categoría nueva conservando sus permisos».
- «Renombra este rol a Programador y ponlo azul».
- «Asigna Programador a estas dos personas».
- «Configura el canal de anuncios: todos pueden leerlo y solo Staff puede escribir».
- «Dale a Programador permiso para gestionar canales, sin tocar sus otros permisos».
- «Borra estos canales duplicados por sus IDs y conserva los demás».

Los nombres iguales se resuelven con el inventario y el contexto; si no hay un destino inequívoco, el asistente pide el ID concreto.

## Tienda web y paneles desde el asistente

Owner → Configurar IA incorpora tres capacidades independientes, desactivadas inicialmente: **Configurar productos de la tienda web y Discord**, **Configurar paneles de bonos** y **Publicar y editar paneles de tienda, bonos y verificación**. La persona debe tener Gestionar servidor (o ser propietaria), acceso privado al asistente y autorización en la matriz del comando correspondiente. Configurar roles que entrega o retira un producto exige además Gestionar roles, la jerarquía adecuada y no conceder privilegios que no tengan la persona y el bot.

`shop_configuration` consulta productos activos e inactivos y configuraciones de bonos. `configure_shop_item` crea o edita nombre, descripción, precio, stock, límite de compras, respuesta personalizada, icono, requisitos, roles y disponibilidad. La web y Discord usan la misma base de datos. Al editar se conservan los campos omitidos; stock=-1 significa ilimitado y max_per_user=0 permite compras sin límite por persona. Desactivar un producto lo retira de venta conservando los inventarios existentes.

`configure_bonus_panel` crea o modifica textos, importe, modalidad, intervalo, etiqueta del botón, requisitos y disponibilidad, sin distribuir dinero ni borrar reclamos. Los cambios de configuración no actualizan automáticamente mensajes ya publicados.

`publish_panel` construye un panel funcional mediante los generadores existentes del bot y lo publica en el canal solicitado. Con message_id actualiza ese mismo mensaje, siempre que sea del bot y del mismo tipo; para bonos exige también el panel_id. Permite aplicar título, descripción y color al mensaje generado, conservando los botones reales. Al reconstruir un panel se usan los datos actuales y las opciones visuales indicadas en esa petición. Las menciones no generan avisos. Estas opciones personalizan mensajes de Discord, no el diseño de la página web.

Ejemplos: «Crea en la tienda un producto Radio por 250 créditos, con 20 unidades», «Cambia el precio del producto 4 a 300 y conserva lo demás», «Retira de venta el producto 4», «Crea un bono de 100 créditos cada 24 horas», «Publica la tienda en #tienda», «Actualiza el panel de verificación del mensaje ID … con el título Bienvenidos y color #123456». Publicar o editar mensajes requiere una orden de publicación o actualización; pedir ideas o un borrador solo permite preparar un plan.

## Historial y límites

La web tiene un botón **＋ Nuevo chat** en la cabecera y el selector **Tus conversaciones**. Cada cuenta tiene chats separados por servidor. Web y Discord comparten la conversación activa; `/asistente nuevo` cambia esa misma selección. El título se toma de la primera petición, sin pedir al modelo que lo genere. El historial previo a esta actualización se migra a **Conversación anterior**, conservando mensajes, resultados de herramientas y recibos para no repetir acciones.

Abrir un chat nuevo no llama a DeepSeek. La siguiente petición incluye únicamente el historial de ese chat; los mensajes y planes pendientes de otros chats no se envían ni a la respuesta principal ni a la interpretación de autorizaciones. Los otros chats siguen accesibles desde el selector. Las instrucciones y definiciones de herramientas sí siguen formando parte de las peticiones al modelo, por lo que una consulta nueva tiene consumo aunque su historial esté vacío.

Se muestran y se usan como contexto los últimos 20 turnos de los últimos 30 días de la conversación elegida, con las respuestas previas acotadas a 4000 caracteres por turno. La limpieza de mensajes antiguos ocurre al recibir una consulta nueva; los títulos e identificadores de las conversaciones permanecen guardados. El consumo de las últimas 24 horas y el cupo diario, si existe, se calculan para la cuenta en ese servidor entre todos sus chats; crear otro chat no los reinicia.

Mientras una petición está ejecutándose no se cambia de chat: se espera a que quede registrado el resultado de sus acciones. Los reintentos conservan su ID y su conversación. Si otra pestaña o Discord cambia la selección, una petición web con la selección antigua se rechaza antes de llamar al modelo y la interfaz actualiza el chat activo. Los endpoints exigen la identidad del propietario de la conversación, el servidor correspondiente y CSRF para crear o seleccionar.

`ASSISTANT_DAILY_LIMIT=0` desactiva el cupo diario del bot; es el valor predeterminado. El propietario también puede guardar 0 desde `/owner` para cada comunidad, o elegir un cupo positivo por persona en una ventana móvil de 24 horas. La configuración particular de la comunidad tiene prioridad sobre el valor del alojamiento. Ya no hay cortes fijos de dos creaciones, seis herramientas o cinco rondas por petición. Se mantiene el tiempo máximo configurable de la tarea y dos consultas simultáneas en total, una por usuario, para que las peticiones terminen y no se solapen sobre la misma conversación. La disponibilidad, el contexto y las cuotas reales de DeepSeek y Discord siguen aplicando.

Con DeepSeek directo se desactiva el modo de pensamiento para estas consultas administrativas breves. Cualquier razonamiento adicional del proveedor se utiliza solamente para continuar sus herramientas y no se muestra ni se persiste en el historial.

Una petición repetida con el mismo identificador devuelve su resultado sin volver a ejecutar herramientas. El navegador conserva ese identificador si falla el transporte. Si el proveedor falla tras una creación, se comunica lo que ya se creó. No hay reintento automático de escrituras. Tras una caída del proceso en mitad de una operación, revisa Discord y auditoría antes de repetirla: una petición pendiente no se reejecuta automáticamente.

## Validación

`npm run test:tactical` incluye pruebas de aislamiento por usuario, acceso por IDs, CSRF, permisos nativos, bloqueo de instrucciones incrustadas en mensajes, herramientas y parámetros no permitidos, reintentos sin duplicados, fallos tras una creación y respuesta privada desde Discord.
