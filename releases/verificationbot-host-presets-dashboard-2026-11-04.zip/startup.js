// Manual host release: run the uploaded local code.
require('./src/index.js');
